package model;

public enum BearTypes {
    BLACK("BLACK"),
    WHITE("WHITE")
    //todo add supported bear_types
    ;

    BearTypes(String name) {
    }
}
