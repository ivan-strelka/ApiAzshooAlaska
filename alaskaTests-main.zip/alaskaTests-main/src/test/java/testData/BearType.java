package testData;

public enum BearType {
    POLAR,
    BROWN,
    BLACK,
    GUMMY;
}
